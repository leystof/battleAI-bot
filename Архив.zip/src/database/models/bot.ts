import { Bot as DefaultBot } from 'grammy'

import { Context } from './context'

export type Bot = DefaultBot<Context>