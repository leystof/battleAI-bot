export function formatIntWithDot(num: string | number): string {
    return Number(num).toLocaleString('de-DE');
}