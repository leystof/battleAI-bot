import {User} from "@/database/models/user";

export async function addWager(user: User, amount: number) {}
export async function pickUpWager(user: User, amount: number) {}