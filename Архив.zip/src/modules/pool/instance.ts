import { PlayerPool } from './pool'

export const pool = new PlayerPool()