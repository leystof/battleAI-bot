import {Composer, InlineKeyboard, Keyboard} from "grammy";
import {Context} from "@/database/models/context";
export const composer = new Composer<Context>()
composer.callbackQuery('wallet topup provider', start)
composer.hears('💰 Пополнить', startCallback)

const text = () => {
    return `<b>Выберите способ пополнения</b>`
}

const keyb = () => {
    return new InlineKeyboard()
        .text("RUB", "wallet topup provider rub")
        .text("Криптовалюта", "wallet topup provider crypto")
        .text("🔙 Назад к кошельку", "wallet menu")
}
async function start(ctx) {
    return ctx.reply(text(),{
        reply_markup: keyb()
    })
}
